#ifndef WORLD_H
#define WORLD_H
#include "BeePlayer.h"
#include "RivalBee.h"
#include "WindMill.h"
#include <vector>
#include "Flower.h"
#include "House.h"
#include "Tree.h"
#include "Person.h"
#include "Tokens.h"

class World
{
    public:
        BeePlayer *bee;
        RivalBee  *rB;
        Person  *person;
        WindMill *windmill;
        Tree *tree;
        Tokens *token;
        Flower *flower;
        House *house;

        World();
        void render();
        void moveBeeLeft();
        void moveBeeRight();
        void moveBeeUp();
        void moveBeeDown();
        void moveBeeForward();
        void moveBeeBackward();
        bool detectCollision();
        void update();
        void tokenDetection();

    protected:
    private:
        float distance;


};

#endif // WORLD_H
