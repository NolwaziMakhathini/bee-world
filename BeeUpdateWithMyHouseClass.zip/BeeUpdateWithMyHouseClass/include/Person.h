#ifndef PERSON_H
#define PERSON_H


class Person
{
    public:
        float x, y,z;
        float radius;
        Person();
        Person(float x,float y,float z,float radius);
        void update();
        void render();
        //void setNewPos(float x1, float y1,float  z1,float angle);
        void displayObject();

    private:

        void drawPerson();
};

#endif // PERSON_H
