#include "Tokens.h"

//#include "Tokens.h"
#include <GL/glut.h>
//#include "windows.h"
Tokens::Tokens()
{
    //ctor
}
Tokens::Tokens(float x,float y,float z,float radius,float outterRadius,float innerRadius)
{
    this->x=x;
    this->y=y;
    this->z=z;
    this->radius=radius;
    this->outterRadius=outterRadius;
    this->innerRadius=innerRadius;
}
void Tokens::removeToken(){

   glColor4f(0,0,0,0) ;
}
void Tokens::render()
{
    glPushMatrix();
        glColor3f(1.0,0.7,0.0);
        glTranslated(x,y,z);
        drawTokens();

    glPopMatrix();
}

void Tokens::drawTokens(){

        glutSolidTorus(innerRadius,outterRadius,25,25);
}
