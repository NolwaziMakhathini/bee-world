#include "House.h"
//#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h


#include <iostream>
#include <GL/glu.h>


House::House()
{
    //ctor
}


House::House(float x, float y,float z){

this->x=x;
    this->y=y;
    this->z=z;

}

void House:: render()

{
glPushMatrix();
glTranslated(x,y,z);
drawHouse();
glPopMatrix();

}


void House::drawRoof(){


glBegin(GL_QUADS);
 glColor3ub(139, 69, 19);
glVertex3f(-3.0f,3.0f,3.0f);
glVertex3f(-2.0f,5.0f,2.0f);
glVertex3f(2.0f,5.0f,2.0f);
glVertex3f(3.0f,3.0f,3.0f);

glVertex3f(3.0f,3.0f,3.0f);
glVertex3f(2.0f,5.0f,2.0f);
glVertex3f(2.0f,5.0f,-2.0f);
glVertex3f(3.0f,3.0f,-3.0f);

glVertex3f(3.0f,3.0f,-3.0f);
glVertex3f(2.0f,5.0f,-2.0f);
glVertex3f(-2.0f,5.0f,-2.0f);
glVertex3f(-3.0f,3.0f,-3.0f);

glVertex3f(-3.0f,3.0f,-3.0f);
glVertex3f(-2.0f,5.0f,-2.0f);
glVertex3f(-2.0f,5.0f,2.0f);
glVertex3f(-3.0f,3.0f,3.0f);

glEnd();

}


void House:: drawWindows(){

glBegin(GL_QUADS);
 glColor3ub(139, 69, 19);
glVertex2f(0.5f,-0.5f);
glVertex2f(-0.5f,-0.5f);
glVertex2f(-0.5f,0.5f);
glVertex2f(0.5f,0.5f);
glEnd();


}

void House::drawHouse()

{


glPushMatrix();


    //Draw Roof
glPushMatrix();
glTranslated(0.0f,3.0f,0.0f);
drawRoof();
glPopMatrix();

    //Draw Body

    glPushMatrix();
     glColor3ub(222, 184, 135);
    glScaled(1.0f,2.0f,1.0f);
    glutSolidCube(6);
    glPopMatrix();

    //Draw Door
    glPushMatrix();
    glColor3ub(139, 69, 19);
    glScaled(2.0f,4.0f,1.0f);
    glTranslatef(0.0f, 0.0f, -3.0);
    glutSolidCube(1);
    glPopMatrix();

//bottom right window
glPushMatrix();
glTranslatef(-2.0f,2.0f,-3.1f);
drawWindows();
glPopMatrix();

//top right window
glPushMatrix();
glTranslatef(-2.0f,4.0f,-3.1f);
drawWindows();
glPopMatrix();

//bottom left window
glPushMatrix();
glTranslatef(2.0f,2.0f,-3.1f);
drawWindows();
glPopMatrix();

//top left window
glPushMatrix();
glTranslatef(2.0f,4.0f,-3.1f);
drawWindows();
glPopMatrix();

//chimney
    glPushMatrix();
    glColor3f(1.0f,0.0f,0.0f);
    glScaled(1.0f,18.0f,1.0f);
   glTranslated(-3.5f,0.0f,3.0f);
    glutSolidCube(1);
    glPopMatrix();

//roof
glPushMatrix();
glScaled(0.5f,0.5f,0.5f);
glTranslated(9.0f,-2.0f,-6.0f);
drawRoof();
glPopMatrix();


//garage
    glPushMatrix();
    glTranslated(4.5f,-1.0f,-3.0f);
     glColor3ub(222, 184, 135);
    glutSolidCube(3);
    glPopMatrix();

    //draw garage window
    glPushMatrix();
    glTranslated(4.5f,-0.5f,-4.6f);
     glScaled(1.5f,1.5f,1.0f);
    drawWindows();

    glPopMatrix();



}


