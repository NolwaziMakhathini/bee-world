#include "beeplayer.h"
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <iostream>
#include<math.h>



//float lut;      // last update time
 //float angle;  // orientation for radial patrolling


// initialise
BeePlayer::BeePlayer(){
}
BeePlayer::BeePlayer(float x,float y,float z,float sizeFactor,float radius){
    this->x=x;
    this->y=y;
    this->z=z;
    this->radius=radius;
     this->sizeFactor=sizeFactor;


}
// display the player bee
void BeePlayer::render(){
//    update();
    glPushMatrix();
        glTranslated(x, y, z); // move to this position
        glScaled(sizeFactor,sizeFactor,sizeFactor);
        drawBee();
    glPopMatrix();
}

void BeePlayer::drawBee(){

glPushMatrix();
glColor3f(0,0,0);
glTranslated(0,0,2.5);
glutSolidSphere(0.6,25,25);
//eyes
glPushMatrix();
glColor3f(1,1,1);
glTranslated(-0.2,0.45,0.3);
glutSolidSphere(0.15,25,25);
glTranslated(0.25,0,0);
glutSolidSphere(0.15,25,25);
glPushMatrix();
glColor3f(0,0,0);
glTranslated(0,0.1,0);
glutSolidSphere(0.11,25,25);
glTranslated(-0.3,0,0);
glutSolidSphere(0.11,25,25);
glPopMatrix();
glPopMatrix();
glPopMatrix();
//body
glPushMatrix();
glColor3f(1.0,0.8,0);
glScaled(1.2,1.6,3);
glutSolidSphere(0.75,25,25);
//Tail
glPushMatrix();
glColor3f(0,0,0);
glTranslated(0,0,-0.3);
glRotatef(180,1,0,0);
glutSolidCone(0.15,0.7,8,8);
glPopMatrix();
//Black lines
glColor3f(0,0,0);
glutWireSphere(0.75,15,15);
glPopMatrix();
//wings
glPushMatrix();
glColor3f(0,0,0);
glBegin(GL_TRIANGLES);
glVertex3f(1,2,-1.2);
glVertex3f(1,1,1.2);
glVertex3f(0,0.5,0);
glEnd();
glBegin(GL_TRIANGLES);
glVertex3f(-1,2,-1.2);
glVertex3f(-1,1,1.2);
glVertex3f(0,0.5,0);
glEnd();
glPopMatrix();
//legs
glPushMatrix();
glColor3f(0,0,0);
glBegin(GL_LINE_STRIP);
glVertex3f(0,-0.2,1);
glVertex3f(1,-1,1);
glVertex3f(0,-3,1);
glEnd();
glBegin(GL_LINE_STRIP);
glVertex3f(0,-0.2,1);
glVertex3f(-1,-1,1);
glVertex3f(0,-3,1);
glEnd();
glPopMatrix();
glPopMatrix();
}

void BeePlayer::moveBeeLeft(){

x+=1;
}
void BeePlayer::moveBeeRight(){
x-=1;
}
void BeePlayer::moveBeeUp(){
y+=1;
}
void BeePlayer::moveBeeDown(){
y-=1;
}
void BeePlayer::moveBeeForward(){
z+=1;
}
void BeePlayer::moveBeeBackward(){
z-=1;
}
