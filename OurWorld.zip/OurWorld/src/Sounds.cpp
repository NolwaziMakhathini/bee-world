#include "Sounds.h"

Sounds::Sounds()
{
    //ctor
}

Sounds::~Sounds()
{
    //dtor
}
