#ifndef TOKENS_H
#define TOKENS_H


class Tokens
{
    public:
        float x;
        float y;
        float z;
        float radius;
        float outterRadius;
        float innerRadius;
        Tokens();
        Tokens(float x, float y, float z, float radius,float outterRadius,float innerRadius);
        void render();
        void removeToken();
        void drawTokens();
    protected:
    private:
};

#endif // TOKENS_H
