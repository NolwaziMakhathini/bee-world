#include "RivalBee.h"
#include <windows.h>
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <iostream>
#include<math.h>
#include "time.h"


RivalBee::RivalBee()
{
    //ctor
}

RivalBee::RivalBee(float x,float y,float z,float rivalBeeSize,float speed,float p_radius,float radius){

    this->x=x;
    this->y=y;
    this->z=z;
    this->speed=speed;
    this->rivalBeeSize=rivalBeeSize;
    this->p_radius = p_radius;
    this->radius=radius;
    lut = glutGet(GLUT_ELAPSED_TIME);
    direction=1; // horizontally right
    ph_limit = x+p_radius;
    nh_limit = x-p_radius;
}
void RivalBee::update(){
        update_linear();
}
void RivalBee::update_linear(){
    int time = glutGet(GLUT_ELAPSED_TIME); // get the elapsed time in milliseconds since glutInit() was executed

    int t_elapsed = time - lut;

    float dist = speed * t_elapsed/1000.0;

    // shift horizontally from current position negative or positive
    if(direction==1) { // postive
        float nx = x+dist;
        // check if nx is greater than cx+radius

        if(nx > ph_limit){
            direction = -1; // change direction to negative
            x = ph_limit;
        }else
            x=nx;
    }else{ // negative
        float nx = x-dist;
        if(nx < nh_limit){
            direction = 1; // change direction to postive
            x = nh_limit;
        }else
            x=nx;
    }

    lut = time;

}
void RivalBee::render(){
    //update();
    glPushMatrix();
        glColor3f(1.0,1.0,1.0);
        glScaled(rivalBeeSize,rivalBeeSize,rivalBeeSize);
        glTranslated(x,y,z);
        drawRivalBee();
    glPopMatrix();

}

void RivalBee::drawRivalBee(){
BeePlayer rB = BeePlayer(x,y,z,0,radius);

rB.drawBee();

}
