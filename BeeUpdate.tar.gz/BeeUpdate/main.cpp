#include <GL/glut.h>
#include <math.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include<ctime>
#include "time.h"
#include "imageloader.h"
#include "BeePlayer.h"
#include "RivalBee.h"
#include "WindMill.h"
#include <vector>
#include "Flower.h"
//#include "Sprinkler.h"
#include "Tree.h"
#include "Person.h"


using namespace std;
  Tree buhle  = Tree(0.15,1.0,-8.0,-4.0,3.0);
   Person rue = Person(-8.0,0.0,-18.0);
 RivalBee thendo= RivalBee(-12.0,2.0,-45.0,0.5,3,3);
BeePlayer s = BeePlayer(-8, 2, -15,0.75,0.6,1.58);

WindMill windmill = WindMill(12,0.0,19.0,3.5,0.0);
Flower nolwazi= Flower(-12,0,-19);
//Sprinkler sprinkler;

static float angle =0.0, ratio;
static float x= 90.0f, y=-1.75f, z = 250.0f;
static float lx = 0.1990f, ly = 0.0f, lz = -0.980f;

float hx = 90.0f, hy = -2.0f, hz = 245.0f;
float cx = 0.0f, cy = -2.0f, cz = 2.0f;
float gx = 0.0f;
float gy = -2.0f;
float gz = 2.0f;
float ex = 0.0f, ey = 0.0f, ez = 2.0f;
float tx = 0.0f;
float ty = -2.0f;
float tz = 0.0f;
float tBase = 0.22, tHeight = 3.0;
//const float PI = 22.0/7.0;
const int FPS = 30;

// Global variables
float x_rotation=0;
float y_rotation=0;
int time1 =0;
float turn_inc;
float z_dist_at;
float camera[3][3] = {
            {0, 0, -z_dist_at},
            {0, 0, 0},
            {0, 1.0f, 0}
    };

GLuint _tGrassId;
GLuint _tSkyId;
//Bee ourBee;
void resetCamera(){
		angle = 0;
		lx=0;
		lz=z_dist_at;
		camera[0][2] =  -z_dist_at;
}
float sx=1;
float sy=2;
float sz=-15;
float wx=12;
float wy=0.0;
float wz=19.0;
float angle_wind=0.0;
float fx=-12;
float fy=0.0;
float fz=-19.0;

void changeSize(int w, int h){

	// Prevent a divide by zero, when window is too short
	// (you cant make a window of zero width).
	if(h == 0)
		h = 1;

	ratio = 1.0f * w / h;
	// Reset the coordinate system before modifying
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// Set the viewport to be the entire window
    glViewport(0, 0, w, h);

	// Set the clipping volume
	gluPerspective(45,ratio,1,1000);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(x, y, z,
		      x + lx,y + ly,z + lz,
			  0.0f,1.0f,0.0f);
}

GLuint loadTexture(Image* image) {
	GLuint textureId;
	glGenTextures(1, &textureId); //Make room for our texture
	glBindTexture(GL_TEXTURE_2D, textureId); //Tell OpenGL which texture to edit
	//Map the image to the texture
	glTexImage2D(GL_TEXTURE_2D,                //Always GL_TEXTURE_2D
				 0,                            //0 for now
				 GL_RGB,                       //Format OpenGL uses for image
				 image->width, image->height,  //Width and height
				 0,                            //The border of the image
				 GL_RGB, //GL_RGB, because pixels are stored in RGB format
				 GL_UNSIGNED_BYTE, //GL_UNSIGNED_BYTE, because pixels are stored
				                   //as unsigned numbers
				 image->pixels);               //The actual pixel data
	return textureId; //Returns the id of the texture
}

/* Initialize OpenGL Graphics */
void init(){
    glClearDepth(1.0f);                   // Set background depth to farthest
    glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);
	glEnable(GL_COLOR_MATERIAL);
    glDepthFunc(GL_LEQUAL);    // Set the type of depth-test
    glShadeModel(GL_SMOOTH);   // Enable smooth shading
   glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);  // Nice perspective corrections
    glClearColor(0, 0, 0, 1); // White and opaque
	Image* grass = loadBMP("/home/MSCS-AD/212502182/PELICAN-Homedir/COMP315/NDLOVUNN_212502182/BeeUpdate/images/grass2.bmp");
	_tGrassId = loadTexture(grass);
	delete grass;

    Image* sky = loadBMP("/home/MSCS-AD/212502182/PELICAN-Homedir/COMP315/NDLOVUNN_212502182/BeeUpdate/images/sky2.bmp");
	_tSkyId = loadTexture(sky);
	delete sky;




    //glEnable(GL_DEPTH_TEST); // turns on hidden surface removal so that objects behind other objects do not get displayed

    turn_inc = 2.0; // in degrees

    z_dist_at = 35.0;

    resetCamera();


}

void setCamera(){

		cout << angle << " lx: " << lx << " lz:" << lz << "\n";
    	// Set the camera

		gluLookAt(	camera[0][0], camera[0][1], camera[0][2],
    				camera[1][0], camera[1][1], camera[1][2],
    				camera[2][0], camera[2][1], camera[2][2]  );

}

void lookAround(){
    cout << "\n Looking around \n";
    // distance
    for(int i=360; i>=0; i-=0.0001){
        double a = M_PI*i/180.0;

        lx = z_dist_at * sin(a);
        lz = z_dist_at * cos(a);

		cout << angle << " lx: " << lx << " lz:" << lz << "\n";

        camera[1][0]=camera[1][0]+lx;
        camera[1][2]=camera[1][2]+lz;

        glutPostRedisplay();

        time1 = glutGet(GLUT_ELAPSED_TIME); // get the elapsed time in milliseconds since glutInit() was executed

        glutPostRedisplay();

    }

    cout << "\n Completed looking around \n";
        //glutTimerFunc(1000/v, myTimer, v);  //could use a timer function to repeat instead of a loop

}

void myTimer(){

}

//ground
void drawGround(){
    glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _tGrassId);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    glBegin(GL_QUADS);
        glNormal3f(0.0, 1.0f, 0.0f);
        glTexCoord2f(0.0f, 0.0f);
        glVertex3f(-500.0f, -2.0f, -500.0f);
        glTexCoord2f(80.0f, 0.0f);
        glVertex3f(-500.0f, -2.0f, 500.0f);
        glTexCoord2f(80.0f, 80.0f);
        glVertex3f(500.0f, -2.0f, 500.0f);
        glTexCoord2f(0.0f, 80.0f);
        glVertex3f(500.0f, -2.0f, -500.0f);
	glEnd();
	glDisable(GL_TEXTURE_2D);
}

//sky
void drawSky(){
    glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _tSkyId);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    glBegin(GL_QUADS);
        glNormal3f(0.0, 1.0f, 0.0f);
        glTexCoord2f(0.0f, 0.0f);
        glVertex3f(-500.0f, -2.0f, -500.0f);
        glTexCoord2f(20.0f, 0.0f);
        glVertex3f(-500.0f, -2.0f, 500.0f);
        glTexCoord2f(20.0f, 20.0f);
        glVertex3f(500.0f, -2.0f, 500.0f);
        glTexCoord2f(0.0f, 20.0f);
        glVertex3f(500.0f, -2.0f, -500.0f);
	glEnd();
	glDisable(GL_TEXTURE_2D);
}

void drawRiver(){
    /*glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _tRiverId);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);*/

    glBegin(GL_QUADS);
        glNormal3f(0.0, 1.0f, 0.0f);
        //glTexCoord2f(0.0f, 0.0f);
        glVertex3f(-50.0f, -2.0f, 50.0f);
        //glTexCoord2f(1.0f, 0.0f);
        glVertex3f(50.0f, -2.0f, 50.0f);
        //glTexCoord2f(1.0f, 1.0f);
        glVertex3f(50.0f, 70.0f, 50.0f);
        //glTexCoord2f(0.0f, 1.0f);
        glVertex3f(-50.0f, 70.0f, 50.0f);
	glEnd();
	//glDisable(GL_TEXTURE_2D);
}

void drawMountain(){
    /*glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _tMountainId);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);*/

    glBegin(GL_QUADS);
        glNormal3f(0.0, 1.0f, 0.0f);
        //glTexCoord2f(0.0f, 0.0f);
        glVertex3f(50.0f, -2.0f, 50.0f);
        //glTexCoord2f(1.0f, 0.0f);
        glVertex3f(50.0f, -2.0f, -50.0f);
        //glTexCoord2f(1.0f, 1.0f);
        glVertex3f(50.0f, 70.0f, -50.0f);
        //glTexCoord2f(0.0f, 1.0f);
        glVertex3f(50.0f, 70.0f, 50.0f);
	glEnd();
	//glDisable(GL_TEXTURE_2D);
}

void drawHouse(){
    glPushMatrix();

    //Draw Roof
    glColor3ub(255, 1, 1); // Red
    glPushMatrix();
    glTranslatef(0.0f, 4.1f, 0.0f);
    glRotatef(270.0, 1, 0, 0);
    glutSolidCone(5.0, 5.0, 30, 500);
    glPopMatrix();

    //Draw Body
    glColor3ub(1, 1, 255); // blue
    glPushMatrix();
    glScaled(1.0, 1.6, 1.0); // shrink by half on the x and z axis
    glutSolidCube(6);
    glPopMatrix();

    //Draw Door
    glColor3ub(1, 1, 1); // blue
    glPushMatrix();
        glTranslatef(0.0f, -2.0f, -2.8);
        glScaled(0.4, 1.3, 0.4); // shrink by half on the x and z axis
        glutSolidCube(3);
    glPopMatrix();

    glPopMatrix();
}


void drawEnvironment(){

	//glTranslatef(0.0f, 1.0f, -6.0f);
	glClearColor(0.0, 0.0, 0.0, 1.0);

	// Create light components
	GLfloat ambientLight[] = { 0.3, 0.3, 0.3, 1.0 };
	GLfloat diffuseLight[] = { 1.0, 1.0, 1.0, 1.0 };;
	GLfloat light_position[] = {10.0, 20.0, 10.0, 1.0};

	// Assign created components to GL_LIGHT0
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLight);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	// enable a light source
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
//
   // glClearColor(0,0,0,1);
	glPushMatrix();
        //glColor3f(0,0.64,0);
        glTranslatef(0.0f, -2.0f, 0.0f);
        drawGround();
	glPopMatrix();

	//Sky
    glPushMatrix();
        //glColor3f(0,0,1);
        glTranslatef(0.0f, 20.0f, 0.0f);
        drawSky();
	glPopMatrix();

    //Mountain
	glPushMatrix();
        glColor3f(1,1,1);
        glTranslatef(0.0f, -2.0f, 0.0f);
        drawMountain();
	glPopMatrix();

	//River
	glPushMatrix();
        glTranslatef(0.0f, -2.0f, 0.0f);
        drawRiver();
	glPopMatrix();

	//Mountain2
	glPushMatrix();
        glColor3f(1,1,1);
        glTranslatef(-100.0f, -2.0f, 0.0f);
        drawMountain();
	glPopMatrix();

	//River2
	glPushMatrix();
        glTranslatef(0.0f, -2.0f, -100.0f);
        drawRiver();
	glPopMatrix();

	glPushMatrix();
        glTranslatef(0.0f, -2.0f, 0.0f);
        //glScalef(100.0f,100.0f,100.0f);
        drawHouse();
	glPopMatrix();
}

void render()
{

    // GL_DEPTH_BUFFER_BIT - resets the depth test values for hidden surface removal
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Reset transformations
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    // Set the camera
    /*gluLookAt(0, 5, -50, // camera position
                  0, 0, 0, // look at position, line of sight
                  0, 1, 0); // up direction (vector) for camera tilt
*/
    setCamera();


    drawEnvironment();

    // place a solid cube at the origin

//    ourBee.render();

    glPushMatrix();
    s.render();
    glPopMatrix();

//    sprinkler.DrawFountain();
    glPushMatrix();
        rue.render();
    glPopMatrix();
    glPushMatrix();
        thendo.render();
    glPopMatrix();
    glPushMatrix();
        buhle.display();
    glPopMatrix();
    glPushMatrix();
        windmill.render();
    glPopMatrix();

    glPushMatrix();
        nolwazi.render();
    glPopMatrix();

    glFlush();   // ******** DO NOT FORGET THIS **********

}


void update()
{
    time1 = glutGet(GLUT_ELAPSED_TIME); // get the elapsed time in milliseconds since glutInit() was executed
    // do nothing
}
/* Handler for window-repaint event. Call back when the window first appears and
   whenever the window needs to be re-painted. */
void display()
{
    //update(); // no need to update all done in render
    render();
}

/* Handler for window re-size event. Called back when the window first appears and
   whenever the window is re-sized with its new width and height */

void reshape(int w, int h)
{

    // Prevent a divide by zero, when window is too short
    // (you cant make a window of zero width).
    if(h == 0)	h = 1;

    GLfloat ratio = 1.0f * (GLfloat)w / (GLfloat)h;

    // Set the viewport to be the entire window
    glViewport(0, 0, w, h);

    // Reset the coordinate system before modifying
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    // Set the clipping volume
    gluPerspective(45, ratio, 0.1, 100);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();



}

void processNormalKeys(unsigned char key, int x, int y) {

	switch (key) {
	    case 'a' : s.moveBeeLeft(); break;
	    case 's' : s.moveBeeRight(); break;
	    case 'w' : s.moveBeeUp(); break;
	    case 'z' : s.moveBeeDown(); break;
	    case 'f' : s.moveBeeForward(); break;
	    case 'b' : s.moveBeeBackward(); break;
		case 'l' : lookAround(); break;
		case 27 :  exit(0); break;
	}
    glutPostRedisplay();
}


void inputKey(int key, int ix, int iy) {
    float a, x, z;
	switch (key) {
		case GLUT_KEY_LEFT :
        	angle += turn_inc;
			a = M_PI*angle/180.0;
			lx = z_dist_at *sin(a);
			lz = z_dist_at *cos(a);
			camera[1][0]=camera[0][0]+lx;
			camera[1][2]=camera[0][2]+lz;
            break;

		case GLUT_KEY_RIGHT :
           	angle -= turn_inc;
			a = M_PI*angle/180.0;
			lx = z_dist_at *sin(a);
			lz = z_dist_at *cos(a);
			camera[1][0]=camera[0][0]+lx;
			camera[1][2]=camera[0][2]+lz;
		    break;

		case GLUT_KEY_UP :
		    a = M_PI*angle/180.0;
			x =  sin(a);
			z = cos(a);
        	camera[0][0] += x; // move x by
            camera[0][2] += z;
        	camera[1][0] += x; // move x by
            camera[1][2] += z;
		    break;
		case GLUT_KEY_DOWN :
		    a = M_PI*angle/180.0;
			x =  sin(a);
			z = cos(a);
        	camera[0][0] -= x; // move x by
            camera[0][2] -= z;
        	camera[1][0] -= x; // move x by
            camera[1][2] -= z;
            break;
	}

    glutPostRedisplay();
}

void idle(){
    glutPostRedisplay(); // called when there is now other event
}

/* Main function: GLUT runs as a console application starting at main() */
int main(int argc, char** argv)
{
    glutInit(&argc, argv);          // Initialize GLUT

    glutInitWindowSize(640, 480);   // Set the window's initial width & height - non-square
    glutInitWindowPosition(50, 50); // Position the window's initial top-left corner
    glutCreateWindow("Bee");  // Create window with the given title

    init();                       // Our own OpenGL initialization
    glutDisplayFunc(display);       // Register callback handler for window re-paint event
    glutReshapeFunc(reshape);       // Register callback handler for window re-size event

	glutKeyboardFunc(processNormalKeys);
	glutSpecialFunc(inputKey);

    //glutTimerFunc(1000,myTimer,FPS);
    glutIdleFunc(idle);

    glutMainLoop();                 // Enter the infinite event-processing loop

return 0;
}
