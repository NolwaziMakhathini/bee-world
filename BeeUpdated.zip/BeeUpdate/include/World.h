#ifndef WORLD_H
#define WORLD_H
#include "BeePlayer.h"
#include "RivalBee.h"
#include "WindMill.h"
#include <vector>
#include "Flower.h"
//#include "Sprinkler.h"
#include "Tree.h"
#include "Person.h"

class World
{
    public:
        BeePlayer *bee;
        RivalBee  *rB;
        Person  *person;
        WindMill *windmill;
        Tree *tree;
        Flower *flower;
        World();
        void render();
        void moveBeeLeft();
        void moveBeeRight();
        void moveBeeUp();
        void moveBeeDown();
        void moveBeeForward();
        void moveBeeBackward();
        bool detectCollision1();
        bool detectCollision2();
        bool detectCollision3();
    protected:
    private:
        float  r1;
        float  r2;
         float r3;
        float distance;


};

#endif // WORLD_H
